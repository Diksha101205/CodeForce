# AI Real-World Battlefield — Unity Port

This folder is a Unity-native port of the supplied React/TensorFlow.js MVP.

## What was converted
- React state/UI flow → Unity C# MonoBehaviours + Unity UI
- Browser webcam → `WebCamTexture`
- HTML canvas overlay → `DetectionOverlay` + `RectTransform` bounding boxes
- Confidence filtering (50%) → `confidenceThreshold`
- Start/Stop webcam controls
- Live detected-object list
- Pipeline/status messages
- Person bounding boxes use the original red visual convention; other classes use green.

## Important: real AI model
The original app uses TensorFlow.js COCO-SSD. TensorFlow.js browser model files are not automatically usable as a Unity model.

For real inference in Unity:
1. Export/use a compatible object detector as ONNX.
2. Put the `.onnx` model in `Assets/Models`.
3. Install Unity Sentis / AI Inference package.
4. Connect preprocessing + model execution + COCO/YOLO post-processing in `SentisObjectDetector.cs`.
5. Set `demoMode = false` in `BattlefieldApp`.

The current project includes a DEMO mode so the Unity scene can be tested immediately without pretending that fake boxes are AI detections.

## Unity version
Created for Unity 6 / 6000.0.43f1.

## Scene setup
A fully serialized scene is not included because Unity UI prefab serialization is very version-sensitive. Open Unity, create a scene, add a Canvas, RawImage, Panel, Texts and Buttons, then attach the scripts as described in `BattlefieldApp` and `WebcamController`.

A quick setup:
- Canvas
  - CameraArea / RawImage
  - DetectionOverlay (RectTransform)
  - StartButton
  - StopButton
  - StatusText
  - ObjectsText
- Empty GameObject `BattlefieldApp`
  - `WebcamController`
  - `DetectionOverlay`
  - `BattlefieldApp`

Assign the references in the Inspector.

## Mapping from React
React `getUserMedia` -> Unity `WebCamTexture`
React `<video>` -> Unity `RawImage`
React `<canvas>` -> `DetectionOverlay`
React `model.detect(video)` -> Sentis/ONNX inference integration point
React `setObjects()` -> C# `List<Detection>`
React 50% filter -> `confidenceThreshold = 0.5`
